var num = prompt()
var copy_num = num;
var count = 0;
for(let i; copy_num != 0; i++){
    copy_num  = copy_num / 10;
    copy_num  = parseInt(copy_num);
    console.log(copy_num);
    count = count + 1;
}
console.log('количесячс разряд: ' + count)
var copy_num = num;
conech_proizv = 1;
for(let i = 1;i < count;i++){
    conech_proizv = conech_proizv * 10;
    
}
console.log('первый разряджж'+ conech_proizv);
let a = 0;
for (let i = 1; i <= count / 2; i++) { 
    let last_number = Math.floor(num / conech_proizv);
    let f_number = num % 10;
    if (last_number !== f_number) {
        a += 1;
        break;
    }
    num = Math.floor(num % conech_proizv / 10);
    conech_proizv = Math.floor(conech_proizv / 100);
}
if (a) { 
    console.log('Не палиндром');
}
 else {
    console.log('полендром');
}







itogovoe_chislo = ''
copy_num = num
function perevorot_chisla(){
    for(let i = count; i <= count;i--){
        itogovoe_chislo = itogovoe_chislo + num/(10 ** i)
    }
    
    console.log(itogovoe_chislo)
}
