function calculate(){
    var summ = 0;
    var numbers_integers = " ";
    var list_insert_numbers = " ";
    var num = document.getElementById("inputn").value;
    if (num > 0){
        for (let i = 0; i < num; i++){
            var c = prompt('Введите число');
            numbers_integers = numbers_integers + parseInt(c) + ' ';
            list_insert_numbers =list_insert_numbers + c + ' | ';
            summ = summ + parseInt(c)
        }   
        document.getElementById("divResult").innerHTML =  'Все целые части чисел подряд ' + (numbers_integers);
        document.getElementById("divResultlist").innerHTML = 'Введденные вами числа  ' +list_insert_numbers;
        document.getElementById("divResultlist_integers_numbers").innerHTML = 'Cумма целых частей введенных вами чисел: ' +summ;
    }
}