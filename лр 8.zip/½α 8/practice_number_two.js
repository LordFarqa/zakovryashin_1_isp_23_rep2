var num = prompt('Введите число корень которого вы хотите получить');
var i = 1;
main_cicle: while(true){
    i++;
    if ((i * i) == num){
        alert(i);
        break main_cicle;
    }
    console.log(i);
}