import random
from tkinter import *

window = Tk()

canva = Canvas(width=700, height=700, bg="lightgreen")

canva.pack()


class Ball:
    def __init__(self, y1, y2, x1, x2, color):
        self.x1 = x1
        self.x2 = x2
        self.y1 = y1
        self.y2 = y2
        self.color = color
        self.ball = canva.create_oval(self.x1, self.x2, self.y1, self.y2, fill=self.color)
        self.vx = random.choice([-20, 20, 20, -30])
        self.vy = random.choice([-15, 6, 5, 325])

        self.MoveBall()

    def MoveBall(self):
        self.x1, self.y1, self.x2, self.y2 = canva.coords(self.ball)
        if self.y1 <= 0 or self.y2 >= 690:
            self.vy *= -1
        if self.x1 <= 0 or self.x2 >= 690:
            self.vx *= -1
        canva.move(self.ball, self.vx, self.vy)
        canva.after(100, self.MoveBall)


color = ['red', 'green', 'blue', 'orange', 'pink', 'magenta',
         'AliceBlue',
         'antique white',
         'AntiqueWhite',
         'AntiqueWhite1',
         'aquamarine',
         'aquamarine4',
         'azure',
         'azure4',
         'beige',
         'bisque4',
         'black']
for i in range(0, len(color)):
    random_color = random.choice(color)
    x1 = random.randint(60, 600)
    y1 = random.randint(60, 600)
    ball = Ball(x1, y1, x1 + 50, y1 + 50, random_color)
    color.remove(random_color)


window.mainloop()
