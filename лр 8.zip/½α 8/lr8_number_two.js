function calculate(){
    var price_list = ' ';
    var num = document.getElementById("inputn").value;
    for (let i = 1; i < 11; i++){
        price_list = price_list + 'Цена одного кг конфет в рублях: '+num+'р'+" цена за "+ i + ' киллограмм конфет = '+ (i*num).toFixed(2) + '<br>';
        document.getElementById("divResult").innerHTML =  price_list;

    }   
    document.getElementById("divResultlist").innerHTML = 'Введденная вами цена  '+ num + ' рублей за кг конфет';
}