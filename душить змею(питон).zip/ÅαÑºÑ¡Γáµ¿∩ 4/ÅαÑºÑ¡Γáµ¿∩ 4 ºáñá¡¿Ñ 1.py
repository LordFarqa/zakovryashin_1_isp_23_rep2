import random
from tkinter import *

window = Tk()
canvas = Canvas(width=700, height=700, bg="lightgreen")
wall = canvas.create_rectangle(100,100,300,300)
my_ball = canvas.create_oval(300, 300, 350, 350, fill='blue')
canvas.pack()


def move(event):
    x, y = event.x, event.y
    print("x=", x, "y=", y)
    wall_coords = canvas.coords(wall)
    if x-25 > wall_coords[0] and x + 25 < wall_coords[2] \
    and y - 25 > wall_coords[1] and y + 25 < wall_coords[3]:
        canvas.coords(my_ball, x - 25, y - 25, x + 25, y + 25)


# def MoveBall():
#     global vx, vy
#     x1,y1,x2,y2 = canvas.coords(my_ball)
#     if y1 <=0 or y2 >=690:
#         vy *= -1
#     if x1 <= 0 or x2 >= 690:
#         vx *= -1
#     canvas.move(my_ball, vx, vy)
#     canvas.after(50, MoveBall)


vx = random.choice([-20, 20, 20, -30])
vy = random.choice([-15, 6, 5, 325])

canvas.bind("<Motion>", move)

# MoveBall()


window.mainloop()
