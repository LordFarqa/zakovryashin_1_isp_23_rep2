var num = toString(prompt())
console.log(typeof(num))
rstr = ' '
for(let i = num.length-1; i > 0; i--){
    rstr = rstr + num[i]
}
console.log(rstr)