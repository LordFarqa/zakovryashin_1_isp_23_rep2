import random
from tkinter import *
from tkinter import messagebox


def move(event):
    key = event.keysym
    sova_coords = canvas.coords(sova)
    home_coords = canvas.coords(home)
    if sova_coords[0] >= home_coords[0] + 50 and 150 <= sova_coords[1] + 50 <= 170:
        messagebox.showinfo('', 'Денчик добрался до хаты')
    if key == 'Up':
        canvas.move(sova, 0, -10)
    elif key == "Down":
        canvas.move(sova, 0, 10)
    elif key == "Left":
        canvas.move(sova, -10, 0)
    elif key == "Right":
        canvas.move(sova, 10, 0)


window = Tk()
canvas = Canvas(width=1280, height=960, bg="lightgreen")
image = PhotoImage(file="support_for_exibet2.png")
sova = canvas.create_image(100, 100, image=image)
home = canvas.create_rectangle(700,400,300,200, fill='pink')
window.bind('<KeyPress>', move)
canvas.pack()

window.mainloop()
