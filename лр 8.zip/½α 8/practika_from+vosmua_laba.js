var num = prompt('insert number');
num++;
var factorial = 1;
var i = 1;
while (i < num){

    factorial = factorial * i;
    i++;
}
alert('факториал '+factorial)