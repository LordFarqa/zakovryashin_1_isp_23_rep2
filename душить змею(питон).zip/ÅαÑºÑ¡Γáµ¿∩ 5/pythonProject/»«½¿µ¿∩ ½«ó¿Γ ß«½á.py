import random
from tkinter import *


def increase_cscore():
    global score
    score += 1
    score_label.config(text=f'Счет:{score}')


def check_collision(sol_image):
    basket_coords = canvas.coords(basket)
    for sol_image in sol_count:
        sol_image_coords = canvas.coords(sol_image)
        if basket_coords[0] - 75 <=sol_image_coords[0] <= basket_coords[0]\
            + 75 and basket_coords[1] - 25 <= sol_image_coords[1]+50:
            increase_cscore()
            canvas.delete(sol_image)
            sol_count.remove(sol_image)


def setings(z, solflake_speed):
    a = 10
    if score > a:
        z += 10
        a += 5


def move_basket(event):
    key = event.keysym
    if key == 'Left':
        canvas.move(basket, -10, 0)
    elif key == 'Right':
        canvas.move(basket, 10, 0)


def move_sol(sol):
    x, y = canvas.coords(sol)
    canvas.move(sol, 0, solflake_speed)
    if y < 1000:
        window.after(50, move_sol, sol)
    else:
        canvas.delete(sol)
        sol_count.remove(sol)
        create_sol_flake()


def create_sol_flake():
    x = random.randint(0, 1000)
    y = 0
    sol = canvas.create_image(x, y, image=sol_image)
    sol_count.append(sol)
    move_sol(sol)


def span_solflake():
    create_sol_flake()
    check_collision(sol_image)
    window.after(z, span_solflake)


window = Tk()

canvas = Canvas(width=1000, height=1000, bg="#4C566A")
z = 2000
solflake_speed = 5
sol_image = PhotoImage(file='sol_gydman2.png')
image_basket = PhotoImage(file='poliz.png')
basket = canvas.create_image(400, 500, image=image_basket)
sol_count = []
score = 0
score_label = Label(text=f"Счет: {score}", font='Arial 16', bg='#4C566A')
score_label.place(x=10, y=10)
span_solflake()
setings(z, solflake_speed)
window.bind("<Left>", move_basket)
window.bind("<Right>", move_basket)
canvas.pack()

window.mainloop()
