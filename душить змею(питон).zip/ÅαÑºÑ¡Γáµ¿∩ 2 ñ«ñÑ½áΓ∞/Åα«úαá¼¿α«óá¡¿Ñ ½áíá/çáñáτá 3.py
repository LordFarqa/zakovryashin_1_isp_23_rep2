from tkinter import *
def move_ball1():
    canva.move(ball1,40,0)
    if canva.coords(ball1)[2]<500:
        canva.after(50,move_ball1)
window = Tk()

window.geometry("1000x1000")

canva = Canvas(width=500, height=500, bg='khaki')
canva.pack()

ball1 = canva.create_oval(50,50,100,100,fill = 'red')
move_ball1()

window.mainloop()

