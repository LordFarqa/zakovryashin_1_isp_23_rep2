import random
from tkinter import *

window = Tk()

canva = Canvas(width=700, height=700, bg="lightgreen")

canva.pack()



def MoveBall():
    global vx, vy
    x1,y1,x2,y2 = canva.coords(my_ball)
    if y1 <=0 or y2 >=690:
        vy *= -1
    if x1 <= 0 or x2 >= 690:
        vx *= -1
    canva.move(my_ball, vx, vy)
    canva.after(5, MoveBall)


vx = random.choice([-20,20,20,-30])
vy = random.choice([-15,6,5,325])
my_ball = canva.create_oval(300, 300, 350, 350, fill='blue')

MoveBall()

window.mainloop()
