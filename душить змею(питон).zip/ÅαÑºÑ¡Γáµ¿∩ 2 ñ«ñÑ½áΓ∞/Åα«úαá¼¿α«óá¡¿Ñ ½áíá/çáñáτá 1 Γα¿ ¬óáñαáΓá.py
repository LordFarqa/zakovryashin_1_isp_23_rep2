from tkinter import *


def click_function(event):

    canva.itemconfig('blue_rect',fill='red')
    canva.itemconfig('yellow_rect',fill='blue')
    canva.itemconfig('black_rect', fill='blue')
window = Tk()

window.geometry("1000x1000")

canva = Canvas(width=500, height=500, bg='khaki')
canva.pack()

rect1 = canva.create_rectangle(50,50,100,100,fill='blue',tags=('rect','blue_rect'))
rect2 = canva.create_rectangle(50,150,100,200,fill='yellow',tags=('rect','yellow_rect'))
rect3 = canva.create_rectangle(50,250,100,300,fill='black',tags=('rect','black_rect'))
canva.itemconfig(rect1, tags='rect')
canva.tag_bind('rect','<Button-1>',click_function)
window.mainloop()

