from tkinter import *

window = Tk()


class Dom:
    def __init__(self, fundament, top):
        self.fundament = fundament
        self.top = top

    def create_Dom(self):
        self.fundament = canvas.create_rectangle(700, 500, 200, 1000, fill='black')
        self.top = canvas.create_polygon([400,400], [700, 400], [350, 300], fill="gray", outline="yellow")


class Windows:
    def __init__(self, windows):
        self.windows = windows


class Doors:
    def __init__(self, door):
        self.door = door


canvas = Canvas(width=1000, height=1000, bg="#4C566A")


canvas.pack()
window.mainloop()
